/*
 * processlab - part1.c
 *
 * Ecole polytechnique de Montreal, GIGL, Hiver  2024
 * vos noms, prénoms et matricules
 * Sandakli, Sobhi, 2136216
 * El-Akhras, Ali, 2143326 
*/

#include "libprocesslab/libprocesslab.h"

// TODO
// Si besoin, ajouter ici les directives d'inclusion
// -------------------------------------------------
// -------------------------------------------------

int CountChildren()
{
    int status;
    int childCounter = 0;

    while (wait(&status) > 0)
    {
        childCounter++;
    }
    return childCounter;
}

void question1()
{
    // Pour Level 0
    registerProc(getpid(), getppid(), 0, 0);

    if (fork() == 0)
    {
        // Pour Level 1.1
        registerProc(getpid(), getppid(), 1, 1);

        if (fork() == 0)
        {
            // Pour Level 2.1
            registerProc(getpid(), getppid(), 2, 1);
            _exit(0);
        }
        CountChildren();
        _exit(0);
    }
    wait(NULL);

    if (fork() == 0)
    {
        // Pour Level 1.2
        registerProc(getpid(), getppid(), 1, 2);

        if (fork() == 0)
        {
            // Pour Level 2.2
            registerProc(getpid(), getppid(), 2, 2);
            _exit(0);
        }
        if (fork() == 0)
        {
            // Pour Level 2.3
            registerProc(getpid(), getppid(), 2, 3);
            _exit(0);
        }
        CountChildren();
        _exit(0);
    }
    wait(NULL);

    if (fork() == 0)
    {
        // Pour Level 1.3
        registerProc(getpid(), getppid(), 1, 3);

        if (fork() == 0)
        {
            // Pour Level 2.4
            registerProc(getpid(), getppid(), 2, 4);
            _exit(0);
        }
        if (fork() == 0)
        {
            // Pour Level 2.5
            registerProc(getpid(), getppid(), 2, 5);
            _exit(0);
        }
        if (fork() == 0)
        {
            // Pour Level 2.6
            registerProc(getpid(), getppid(), 2, 6);
            _exit(0);
        }
        CountChildren();
        _exit(0);
    }

    printf("Nombre d'enfants: %d\n", CountChildren());
    printProcRegistrations();
    execl("/usr/bin/ls", "ls", "-l", NULL);
}
